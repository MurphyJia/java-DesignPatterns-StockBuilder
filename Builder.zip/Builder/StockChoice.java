package com.onjava8.DesignPatterns.Builder;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class StockChoice extends MultiChoice {
    private final JPanel panel = new JPanel();
    private final Font font = new Font("monospace", Font.BOLD,20);
    private final String[] message = {
            "Cisco", "Coca Cola", "General Electric", "Harley DavidSon", "IBM", "DOW J", "NIKE",
            "StarBucks Corporation", "China Mobile"
    };

    /**
     * Constructor
     * @param choices A vector to store choices
     */
    public StockChoice(Vector<String> choices) {
        super(choices);
    }

    /**
     * Set a new UI page
     * @return panel the new created panel
     */
    @Override
    public JPanel getUI() {
        // 创建包含列表框的面板
        List list = new List(message.length);
        list.setFont(font);
        list.setMultipleMode(true);
        panel.add(list);
        for (String s : message) {
            list.add(s);
        }

        panel.setVisible(true);

        return panel;
    }
}
