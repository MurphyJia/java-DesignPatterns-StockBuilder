package com.onjava8.DesignPatterns.Builder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Vector;

public class wealthBuilder extends JFrame implements ActionListener {
    private final JButton plot = new JButton("Plot");// Command button
    private final JButton clear = new JButton("Clear");// Clear button
    private final JButton exit = new JButton("Exit");// Exit button
    private final Font font = new Font("monospace", Font.BOLD,20);
    private final JPanel choicePanel = new JPanel();// The left panel
    private final JPanel centralPanel = new JPanel();// The large central panel
    private final JPanel resultPanel = new JPanel();// The right panel
    private static MultiChoice mChoices;// Define some choices
    // Define three vectors
    private static final Vector<String> Bonds = new Vector<>();
    private final Vector<String> Stocks = new Vector<>();
    private final Vector<String> Mutual = new Vector<>();
    private final ChoiceFactory factory;// Factory
    private final String[] choiceMsg = {"Stocks", "Bonds", "Mutual Funds"};// Content
    private final JList<String> choiceList = new JList<>(choiceMsg);// Choice list
    private final String[] mutualMsg = {"Fidelity Magellan", "T Rowe Price", "Vanguard PrimeCap", "Lindner Fund"};
    private final String[] stockMsg = {
            "Cisco", "Coca Cola", "General Electric", "Harley DavidSon", "IBM", "DOW J", "NIKE",
            "StarBucks Corporation", "China Mobile"
    };

    /**
     * Constructor
     */
    public wealthBuilder() {
        super("Wealth Builder");// title
        startUI();// Set UI
        assign();// Assignment content
        factory = new ChoiceFactory();// Build factory
    }

    /**
     * Assignment
     */
    public void assign() {
        Collections.addAll(Mutual, mutualMsg);
        Collections.addAll(Stocks, stockMsg);
    }

    /**
     * Design UI
     */
    private void startUI() {
        JPanel jp = new JPanel();// Bottom panel
        getContentPane().add(jp);
        jp.setLayout(new BorderLayout());
        jp.add(BorderLayout.CENTER, centralPanel);
        jp.add(BorderLayout.NORTH, new JPanel());

        centralPanel.setLayout(new GridLayout(1,2));// Set grid
        JPanel buttonPanel = new JPanel();// Set panel to place buttons
        buttonPanel.setBackground(Color.LIGHT_GRAY);
        jp.add(BorderLayout.SOUTH, buttonPanel);
        plot.setFont(font);
        exit.setFont(font);
        clear.setFont(font);
        plot.setEnabled(false);// It is not activated until a stock is selected
        plot.addActionListener(this);
        exit.addActionListener(this);
        clear.addActionListener(this);
        buttonPanel.add(plot);// Add three buttons to the panel
        buttonPanel.add(exit);
        buttonPanel.add(clear);

        // At first, the right panel is empty
        choicePanel.setBackground(Color.WHITE);
        resultPanel.setBackground(Color.LIGHT_GRAY);
        choiceList.addListSelectionListener(e -> {// Set response
            if(!e.getValueIsAdjusting())
                stockList_Click();
        });

        choicePanel.add(choiceList);
        choiceList.setFont(font);
        centralPanel.add(choicePanel);
        centralPanel.add(resultPanel);
        centralPanel.setVisible(true);
        setBounds(200 , 200,850, 500);
        setVisible(true);
    }

    /**
     * When the list is clicked
     */
    private void stockList_Click() {
        Vector<String> v;
        int index = choiceList.getSelectedIndex();
        choicePanel.removeAll();// Delete the former UI page
        // Switch between three vectors with switch statements
        switch (index) {
            case 0 :
                v = Stocks;
                break;
            case 1 :
                v = Bonds;
                break;
            case 2 :
                v = Mutual;
                break;
            default:// When there is some exception...
                throw new IllegalStateException("Unexpected value: " + index);
        }

        mChoices = factory.getChoiceUI(v);// Get a GUI
        plot.setEnabled(true);// Start
    }

    /**
     * Clear content and start again
     */
    public void clearALL() {
        dispose();// Dispose current page
        new wealthBuilder();// Start a new page? Maybe we can improve it here
    }

    /**
     * ActionPerformed
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == plot) {// When 'plot' button is clicked
            // Insert the new panel to the right
            resultPanel.add(BorderLayout.CENTER, mChoices.getUI());
            resultPanel.validate();// Set the layout again
            resultPanel.repaint();// Repaint
        } else if(e.getSource() == clear) {
            clearALL();// Clear content
        } else if(e.getSource() == exit) {// Exit
            dispose();
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new wealthBuilder();// Start then UI page
    }
}
