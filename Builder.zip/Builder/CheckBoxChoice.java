package com.onjava8.DesignPatterns.Builder;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class CheckBoxChoice extends MultiChoice {
    int count;// Number of check boxes
    JPanel panel;// Panels with checkboxes
    private final Font font = new Font("monospace", Font.BOLD,20);
    String[] messages = {"CT State GO 2012", "New York GO 2005", "GE Crop Bonds"};

    /**
     * Constructor
     * @param choices A vector to store choices
     */
    public CheckBoxChoice(Vector<String> choices) {
        super(choices);
        count = 0;
        panel = new JPanel();
    }

    /**
     * Set a new UI page
     * @return panel the new created panel
     */
    @Override
    public JPanel getUI() {
        // Create a grid layout
        panel.setLayout(new GridLayout(messages.length, 1));
        // Add check box
        for (String message : messages) {
            JCheckBox box = new JCheckBox(message);
            box.setFont(font);
            panel.add(box);
            count++;
        }

        panel.setVisible(true);

        return panel;
    }
}
