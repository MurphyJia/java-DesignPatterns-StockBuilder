package com.onjava8.DesignPatterns.Builder;

import javax.swing.*;
import java.util.Vector;

// Abstract class
public abstract class MultiChoice {
    // Define a vector to store choices
    protected static Vector<String> choices;

    /**
     * Constructor
     * @param choiceList A vector to store choices
     */
    public MultiChoice(Vector<String> choiceList) {
        choices = choiceList;
    }

    // Abstract methods
    abstract public JPanel getUI();// Design UI
}
