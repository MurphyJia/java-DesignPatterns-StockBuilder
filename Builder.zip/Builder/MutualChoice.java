package com.onjava8.DesignPatterns.Builder;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class MutualChoice extends MultiChoice {
    private final JPanel panel = new JPanel();
    private final Font font = new Font("monospace", Font.BOLD,20);// Set font
    private final String[] message = {"Fidelity Magellan", "T Rowe Price", "Vanguard PrimeCap", "Lindner Fund"};

    /**
     * Constructor
     * @param choices A vector to store choices
     */
    public MutualChoice(Vector<String> choices) {
        super(choices);
    }

    /**
     * Set a new UI page
     * @return panel the new created panel
     */
    @Override
    public JPanel getUI() {
        // Create a panel that contains a list box
        List list = new List(message.length);
        list.setFont(font);
        list.setMultipleMode(true);
        panel.add(list);// Add the list to the new panel
        for (String s : message) {
            list.add(s);// Add content
        }

        panel.setVisible(true);

        return panel;
    }
}
