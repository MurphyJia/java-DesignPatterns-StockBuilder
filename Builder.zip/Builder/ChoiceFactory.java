package com.onjava8.DesignPatterns.Builder;

import java.util.Vector;

public class ChoiceFactory {
    MultiChoice ui;// Define an instance but not to assign

    /**
     * Factory--To design which instance could be created
     * @param choices A vector to store choices
     * @return ui the specific instance of three
     */
    public MultiChoice getChoiceUI(Vector<String> choices) {
        if(choices.size() == 0)
            ui = new CheckBoxChoice(choices);// Bonds
        else if(choices.size() == 4)
            ui = new MutualChoice(choices);// Mutual
        else
            ui = new StockChoice(choices);// Stock

        return ui;
    }
}